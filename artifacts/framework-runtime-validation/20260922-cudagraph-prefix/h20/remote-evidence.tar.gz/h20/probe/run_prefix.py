import json,os,sys,time,signal,subprocess,socket,math,urllib.request,traceback
from pathlib import Path

def save(path,obj): Path(path).write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n')
def http(base,path,body=None,timeout=240):
    data=None if body is None else json.dumps(body).encode()
    req=urllib.request.Request(base+path,data=data,headers={'Content-Type':'application/json'})
    with urllib.request.urlopen(req,timeout=timeout) as r:
        text=r.read().decode()
        try: data=json.loads(text)
        except ValueError: data=text
        return {'status':r.status,'body':data}
def metrics(text):
    ans={}
    for line in text.splitlines():
        if line.startswith('#') or not line.strip(): continue
        key,value=line.rsplit(' ',1)
        if any(k in key for k in ('prefix_cache_queries','prefix_cache_hits','cudagraph')):
            try: ans[key]=float(value)
            except ValueError: pass
    return ans

def main():
    job=json.loads(Path(sys.argv[1]).read_text()); out=Path(job['out']); out.mkdir(parents=True,exist_ok=True)
    if (out/'result.json').exists(): raise RuntimeError('completed run exists')
    port=job['port']; base=f'http://127.0.0.1:{port}'
    with socket.socket() as sock:
        sock.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1); sock.bind(('127.0.0.1',port))
    env=dict(os.environ,**job['env']); env.update(MSV_RUNTIME_CAPTURE='1',MSV_RUNTIME_OUT=str(out)); env['PYTHONPATH']=str(Path(__file__).parent)
    save(out/'job.json',job)
    result={'job':job,'started':time.time(),'ready':False,'ok':False,'requests':[]}
    def snapshot(name):
        txt=subprocess.check_output(['nvidia-smi','--query-gpu=index,uuid,name,memory.total,memory.used,utilization.gpu','--format=csv'],text=True)
        (out/f'nvml-{name}.csv').write_text(txt)
        (out/f'processes-{name}.txt').write_text(subprocess.check_output(['nvidia-smi','--query-compute-apps=gpu_uuid,pid,process_name,used_gpu_memory','--format=csv'],text=True))
    def snapmetrics(name):
        text=http(base,'/metrics')['body']; (out/f'metrics-{name}.txt').write_text(text); return metrics(text)
    snapshot('before')
    with (out/'server.log').open('w') as log:
        proc=subprocess.Popen(job['argv'],env=env,stdout=log,stderr=log,start_new_session=True)
        result['server_pid']=proc.pid; (out/'server.pid').write_text(str(proc.pid)+'\n')
        try:
            deadline=time.monotonic()+job.get('startup_timeout',1500)
            while time.monotonic()<deadline and proc.poll() is None:
                try:
                    if http(base,'/health',timeout=2)['status']==200: result['ready']=True; break
                except Exception: pass
                time.sleep(3)
            if not result['ready']: raise RuntimeError(f'not ready rc={proc.poll()}')
            snapshot('post-start'); save(out/'models.json',http(base,'/v1/models'))
            records=[]
            for path in out.glob('capture-*.jsonl'):
                for line in path.read_text().splitlines():
                    try: records.append(json.loads(line))
                    except ValueError: pass
            blocks=[]
            def walk(x):
                if isinstance(x,dict):
                    for k,v in x.items():
                        if k in ('block_size','hash_block_size','scheduler_block_size') and isinstance(v,int) and v>0: blocks.append(v)
                        else: walk(v)
                elif isinstance(x,list):
                    for v in x: walk(v)
            for r in records:
                if r['event'].endswith('initialize_kv_cache') or r['event'].startswith('KVCacheManager'): walk(r)
            if not blocks: raise RuntimeError('no runtime block size captured; cannot prove aligned prefix')
            block=math.lcm(*blocks); prefix_len=max(3*block,math.ceil(1024/block)*block)
            prefix_len=job.get('common_prefix_tokens',prefix_len)
            if prefix_len+256+24>job['max_model_len']: raise RuntimeError(f'actual block={block} prefix={prefix_len} too long for bounded model length')
            phrase='This is a deterministic cache reuse experiment. The blue book is on the wooden table. '
            tok=http(base,'/tokenize',{'model':job['model'],'prompt':phrase,'add_special_tokens':False})['body']['tokens']
            prefix=(tok*math.ceil(prefix_len/len(tok)))[:prefix_len]
            suffixes=[]
            for label in ('Alpha','Beta','Gamma'):
                suffixes.append(http(base,'/tokenize',{'model':job['model'],'prompt':f'\nQuestion {label}: Name the color of the book and explain briefly. Answer:','add_special_tokens':False})['body']['tokens'])
            prompts=[prefix+suffixes[0],prefix+suffixes[0],prefix+suffixes[1],prefix+suffixes[1],prefix+suffixes[2]]
            labels=['cold_alpha','identical_alpha','shared_prefix_beta','identical_beta','shared_prefix_gamma']
            save(out/'prompt-design.json',{'blocks_observed':sorted(set(blocks)),'alignment_lcm':block,'common_prefix_tokens':prefix_len,'common_prefix':prefix,'phrase':phrase,'labels':labels,'prompt_lengths':list(map(len,prompts)),'max_output_tokens':24,'endpoint':'/v1/completions','prompt_format':'exact token IDs eliminates suffix retokenization drift'})
            before=snapmetrics('initial'); result['metrics_initial']=before
            for i,(label,prompt) in enumerate(zip(labels,prompts)):
                pre=snapmetrics(f'{i}-{label}-before')
                body={'model':job['model'],'prompt':prompt,'temperature':0,'seed':42,'max_tokens':24,'ignore_eos':True}
                save(out/f'request-{i}-{label}.json',body); start=time.time(); response=http(base,'/v1/completions',body)
                save(out/f'response-{i}-{label}.json',response)
                time.sleep(2); post=snapmetrics(f'{i}-{label}-after')
                delta={k:post.get(k,0)-pre.get(k,0) for k in set(pre)|set(post)}
                req={'label':label,'elapsed_s':time.time()-start,'status':response['status'],'usage':response['body'].get('usage'),'output':response['body']['choices'][0]['text'],'metrics_before':pre,'metrics_after':post,'metrics_delta':delta}
                result['requests'].append(req); save(out/'progress.json',result)
                if response['status']!=200 or response['body'].get('usage',{}).get('completion_tokens')!=24: raise RuntimeError('generation request failed')
            result['metrics_final']=snapmetrics('final'); result['ok']=True; snapshot('post-requests')
        except Exception as exc:
            result['error']=str(exc); result['traceback']=traceback.format_exc()
        finally:
            result['returncode_before_cleanup']=proc.poll()
            try: os.killpg(proc.pid,signal.SIGTERM)
            except ProcessLookupError: pass
            try: proc.wait(timeout=45)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid,signal.SIGKILL); proc.wait(timeout=15)
            time.sleep(4); result['server_returncode']=proc.returncode; result['finished']=time.time(); snapshot('after-cleanup')
            with socket.socket() as s: result['port_closed']=s.connect_ex(('127.0.0.1',port))!=0
            save(out/'result.json',result)
    print(json.dumps({'out':str(out),'ok':result['ok'],'error':result.get('error'),'port_closed':result['port_closed']}),flush=True)
    return 0 if result['ok'] else 1
if __name__=='__main__': raise SystemExit(main())
