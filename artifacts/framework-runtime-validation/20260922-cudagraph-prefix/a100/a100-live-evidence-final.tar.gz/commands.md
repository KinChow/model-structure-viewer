# A100 command record

Access: `ssh relay` then `ssh root@10.55.87.81`.

## mtp-on-cap12-r3
```sh
CUDA_VISIBLE_DEVICES=GPU-1c2804f0-4d1a-04f0-9686-806ffa6a599f VLLM_LOGGING_LEVEL=DEBUG VLLM_MEMORY_PROFILER_ESTIMATE_CUDAGRAPHS=1 MSV_RUNTIME_CAPTURE=1 MSV_RUNTIME_OUT=/ssd2/zhouzijian01/msv-validation-20260922-cudagraph-prefix/a100/mtp-on-cap12-r3 PYTHONPATH=/ssd2/zhouzijian01/msv-validation-20260922-cudagraph-prefix/a100/harness HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1
vllm serve /ssd2/models/Qwen/Qwen3.5-4B --host 127.0.0.1 --port 18122 --served-model-name a100-prefix-graph --gpu-memory-utilization 0.30 --max-model-len 4096 --max-num-seqs 4 --max-num-batched-tokens 2048 --enable-prefix-caching --cudagraph-metrics --cudagraph-capture-sizes 1 2 3 4 6 8 12 --speculative-config '{"method":"mtp","num_speculative_tokens":2}'
```

## mtp-off-cap12
```sh
CUDA_VISIBLE_DEVICES=GPU-1c2804f0-4d1a-04f0-9686-806ffa6a599f VLLM_LOGGING_LEVEL=DEBUG VLLM_MEMORY_PROFILER_ESTIMATE_CUDAGRAPHS=1 MSV_RUNTIME_CAPTURE=1 MSV_RUNTIME_OUT=/ssd2/zhouzijian01/msv-validation-20260922-cudagraph-prefix/a100/mtp-off-cap12 PYTHONPATH=/ssd2/zhouzijian01/msv-validation-20260922-cudagraph-prefix/a100/harness HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1
vllm serve /ssd2/models/Qwen/Qwen3.5-4B --host 127.0.0.1 --port 18122 --served-model-name a100-prefix-graph --gpu-memory-utilization 0.30 --max-model-len 4096 --max-num-seqs 4 --max-num-batched-tokens 2048 --enable-prefix-caching --cudagraph-metrics --cudagraph-capture-sizes 1 2 3 4 6 8 12
```

