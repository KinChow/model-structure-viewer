import json,pathlib,re,hashlib,os
E=pathlib.Path(__file__).parents[1]
summary={'host':'10.98.95.16','container':'vllm-0920','vllm_version':'0.29.1rc1.dev397+ga8d1aa9c9','vllm_sha':'a8d1aa9c99b8698a2a78b611b7a10c30e6b3995b','image_id':'sha256:38e8c0e60293aefc23edee5c074107e44b89d64f26d5399cd2f5956801b6ef24','image_repo_digest':'sha256:4cbfd34aac145fd1870381c030131c7f868fcad45448f401ecdb5fd4ed020b42','model':'Qwen/Qwen3.5-4B','model_source':'bos:/aihc-private-hcd/LLM/Qwen/Qwen3.5-4B/','model_path':'/ssd2/zhouzijian01/msv-models-20260922/Qwen3.5-4B','runner':'vllm.v1.worker.gpu.model_runner.GPUModelRunner','runs':[]}
for name in ('mtp-on-cap8','mtp-off-cap8','mtp-on-cap32','mtp-off-cap8-sameprompt'):
 p=E/name
 if not (p/'result.json').exists(): continue
 r=json.loads((p/'result.json').read_text()); design=json.loads((p/'prompt-design.json').read_text())
 cap=[json.loads(line) for f in p.glob('capture-*.jsonl') for line in f.read_text().splitlines()]
 cache_records=[x for x in cap if x['event'].endswith('initialize_kv_cache')]; cache=cache_records[-1]['allocation']['kv_cache_config']
 memory=[x for x in cap if x['event']=='Worker.determine_available_memory'][-1]
 graphs=[x for x in cap if x['event'].endswith('.capture_model')]
 log=(p/'server.log').read_text()
 row={'name':name,'ok':r['ok'],'port_closed':r['port_closed'],'server_returncode':r['server_returncode'],'common_prefix_tokens':design['common_prefix_tokens'],'observed_block_sizes':design['blocks_observed'],'num_blocks':cache['num_blocks'],'available_kv_bytes':memory['available_kv_cache_memory_bytes'],'graph_estimate_bytes':memory['cudagraph_memory_estimate'],'graph_capture_bytes':[x['return_value'] for x in graphs],'graph_final_capture_bytes':graphs[-1]['return_value'],'capture_config':graphs[-1]['compilation_config'],'cache_config':graphs[-1]['cache_config'],'cache_groups':cache['kv_cache_groups'],'requests':[], 'evidence_lines':[]}
 for x in r['requests']:
  delta={k.split('{')[0]:v for k,v in x['metrics_delta'].items() if k.startswith('vllm:prefix_') and '_total{' in k}
  row['requests'].append({'label':x['label'],'status':x['status'],'prompt_tokens':x['usage']['prompt_tokens'],'completion_tokens':x['usage']['completion_tokens'],'cached_tokens':x['usage']['prompt_tokens_details']['cached_tokens'],'metrics_delta':delta,'output':x['output']})
 for n,line in enumerate(log.splitlines(),1):
  if any(t in line for t in ['Available KV cache memory:','CUDA graph pool memory:','Graph capturing finished','Speculative decoding (method=','GPU KV cache size:','CG Capture:','| FULL','| NONE']): row['evidence_lines'].append({'line':n,'text':line})
 (p/'extracted-summary.json').write_text(json.dumps(row,indent=2)+'\n'); summary['runs'].append(row)
print(json.dumps([{k:v for k,v in x.items() if k in ['name','ok','common_prefix_tokens','observed_block_sizes','num_blocks','available_kv_bytes','graph_estimate_bytes','graph_capture_bytes','port_closed']} for x in summary['runs']],indent=2))
(E/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
