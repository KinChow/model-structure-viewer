#!/usr/bin/env python3
"""Derived from MSV run_smoke.py: own process group, bounded localhost service.
Native vLLM execution; observer does not alter return values or allocation settings.
"""
import hashlib,json,math,os,signal,socket,subprocess,sys,time,traceback
from pathlib import Path
from run_smoke import request
ROOT=Path('/ssd2/zhouzijian01/msv-validation-20260922-cudagraph-prefix/a100')
MODEL='/ssd2/models/Qwen/Qwen3.5-4B'
def save(p,x): p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
def snapshot(out,name):
    cmds=[['nvidia-smi','--query-gpu=index,uuid,name,memory.total,memory.used,utilization.gpu','--format=csv'],['nvidia-smi','--query-compute-apps=pid,gpu_uuid,process_name,used_memory','--format=csv'],['ps','-eo','pid,ppid,pgid,sid,args']]
    (out/name).write_text('\n'.join('$ '+' '.join(c)+'\n'+subprocess.run(c,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT).stdout for c in cmds))
def metrics(out,name,port):
    text=request(f'http://127.0.0.1:{port}/metrics')['body']; (out/(name+'.prom')).write_text(text)
    vals={}
    for line in text.splitlines():
        if not line or line.startswith('#'): continue
        key,_,val=line.rpartition(' ')
        if any(s in key for s in ('prefix_cache','cudagraph','prompt_tokens','generation_tokens','request_success','spec_decode')):
            try: vals[key]=float(val)
            except ValueError: pass
    save(out/(name+'.json'),vals); return vals

def main(name,mtp,cap,max_len=4096,max_seqs=4):
    out=ROOT/name; out.mkdir(exist_ok=False); port=18122
    raw=subprocess.check_output(['nvidia-smi','--query-gpu=index,uuid,memory.used','--format=csv,noheader,nounits'],text=True)
    rows=[x.split(', ') for x in raw.strip().splitlines()]; chosen=rows[0]
    if int(chosen[2])>8: raise RuntimeError('GPU0 no longer free; refusing launch: '+str(chosen))
    with socket.socket() as s:
        s.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1); s.bind(('127.0.0.1',port))
    sizes=[1,2,3,4,6,8,12] if cap==12 else [1,2,3]
    argv=['vllm','serve',MODEL,'--host','127.0.0.1','--port',str(port),'--served-model-name','a100-prefix-graph','--gpu-memory-utilization','0.30','--max-model-len','4096','--max-num-seqs','4','--max-num-batched-tokens','2048','--enable-prefix-caching','--cudagraph-metrics','--cudagraph-capture-sizes',*map(str,sizes)]
    if mtp: argv+=['--speculative-config','{"method":"mtp","num_speculative_tokens":2}']
    overrides={'CUDA_VISIBLE_DEVICES':chosen[1],'VLLM_LOGGING_LEVEL':'DEBUG','VLLM_MEMORY_PROFILER_ESTIMATE_CUDAGRAPHS':'1','MSV_RUNTIME_CAPTURE':'1','MSV_RUNTIME_OUT':str(out),'PYTHONPATH':str(ROOT/'harness'),'HF_HUB_OFFLINE':'1','TRANSFORMERS_OFFLINE':'1'}
    env=dict(os.environ,**overrides); job={'argv':argv,'env':overrides,'selected_gpu':chosen,'startup_timeout':1500,'mtp':mtp,'cap':cap}; save(out/'job.json',job)
    snapshot(out,'before-start.txt'); result={'ready':False,'ok':False,'started':time.time(),'requests':[]}
    with (out/'server.log').open('w') as log:
        p=subprocess.Popen(argv,env=env,stdout=log,stderr=log,start_new_session=True); save(out/'owned-process.json',{'pid':p.pid,'pgid':p.pid,'argv':argv}); print('START',name,p.pid,flush=True)
        try:
            deadline=time.monotonic()+1500
            while p.poll() is None and time.monotonic()<deadline:
                try:
                    if request(f'http://127.0.0.1:{port}/health',timeout=2)['status']==200: result['ready']=True; break
                except Exception: pass
                time.sleep(3)
            if not result['ready']: raise RuntimeError('server not ready; rc='+str(p.poll()))
            snapshot(out,'after-start.txt')
            try: save(out/'server-info.json',request(f'http://127.0.0.1:{port}/server_info'))
            except Exception as exc: (out/'server-info-error.txt').write_text(repr(exc))
            config=None
            for f in out.glob('capture-*.jsonl'):
                for l in f.read_text().splitlines():
                    d=json.loads(l)
                    if d['event'].endswith('initialize_kv_cache'): config=d['allocation']['kv_cache_config']
            if config is None: raise RuntimeError('no runtime KV group capture; cannot establish alignment')
            blocks=[g['kv_cache_spec']['block_size'] for g in config['kv_cache_groups']]; block=math.lcm(*blocks); common_len=3*block
            if common_len+256>4096: raise RuntimeError('derived >2-block common prefix exceeds context')
            from transformers import AutoTokenizer
            tok=AutoTokenizer.from_pretrained(MODEL,local_files_only=True)
            intro='Read this reference carefully. The archive key is ORANGE. France has capital Paris. Answer the final question briefly.\nReference:\n'
            filler='A library keeps books in ordered shelves. Readers study history, science, mathematics, and art. The archive key remains ORANGE.\n'
            ids=tok.encode(intro+filler*200,add_special_tokens=False)[:common_len]
            suffixes=['\nQuestion A: What is the capital of France?\nAnswer:', '\nQuestion B: What is the archive key?\nAnswer:', '\nQuestion C: What is one plus one?\nAnswer:']
            prompts=[ids+tok.encode(s,add_special_tokens=False) for s in suffixes]
            control=tok.encode('Unrelated new reference. The code is BLUE.\n'+('Cats nap beside quiet windows.\n'*500),add_special_tokens=False)[:common_len]+tok.encode('\nWhat is the code?\nAnswer:',add_special_tokens=False)
            save(out/'prompt-plan.json',{'block_sizes':blocks,'alignment_lcm':block,'common_prefix_tokens':common_len,'common_prefix_sha256':hashlib.sha256(json.dumps(ids).encode()).hexdigest(),'common_prefix_ids':ids,'common_prefix_text':tok.decode(ids),'plan':['cold-A','repeat-A','different-suffix-B','repeat-B','different-suffix-C','cold-unrelated','repeat-A-after-unrelated'],'note':'3 actual group blocks; exact token IDs avoid tokenization boundary ambiguity; no skip cache flag'})
            print('READY',name,'blocks',blocks,'prefix',common_len,flush=True)
            initial=metrics(out,'metrics-initial',port); prev=initial
            for i,(label,tokens) in enumerate([('cold-A',prompts[0]),('repeat-A',prompts[0]),('different-suffix-B',prompts[1]),('repeat-B',prompts[1]),('different-suffix-C',prompts[2]),('cold-unrelated',control),('repeat-A-after-unrelated',prompts[0])]):
                body={'model':'a100-prefix-graph','prompt':tokens,'max_tokens':48,'temperature':0,'seed':922}
                save(out/f'request-{i}-{label}.json',body); before=metrics(out,f'metrics-{i}-before',port); t=time.time(); r=request(f'http://127.0.0.1:{port}/v1/completions',body,timeout=240); r['elapsed_seconds']=time.time()-t; save(out/f'response-{i}-{label}.json',r)
                time.sleep(2); after=metrics(out,f'metrics-{i}-after',port); delta={k:after.get(k,0)-before.get(k,0) for k in set(before)|set(after) if '_created' not in k}
                text=r['body']['choices'][0]['text']; valid=r['status']==200 and bool(text.strip()) and r['body']['usage']['completion_tokens']>0 and '\ufffd' not in text
                row={'label':label,'status':r['status'],'prompt_tokens_sent':len(tokens),'usage':r['body']['usage'],'text':text,'valid_nonempty':valid,'metrics_delta':delta,'elapsed_seconds':r['elapsed_seconds']}; result['requests'].append(row); save(out/'requests-progress.json',result['requests']); print('REQUEST',name,label,'valid',valid,'deltas',{k:v for k,v in delta.items() if 'prefix_cache_' in k},flush=True)
                if not valid: raise RuntimeError('invalid output')
            time.sleep(12); final=metrics(out,'metrics-final',port); result['metrics_total_delta']={k:final.get(k,0)-initial.get(k,0) for k in set(initial)|set(final) if '_created' not in k}; result['ok']=True; snapshot(out,'before-cleanup.txt')
        except Exception as e:
            result['error']=repr(e); (out/'error.txt').write_text(traceback.format_exc()); print('ERROR',name,repr(e),flush=True)
        finally:
            result['returncode_before_cleanup']=p.poll()
            try: os.killpg(p.pid,signal.SIGTERM)
            except ProcessLookupError: pass
            try: p.wait(timeout=60)
            except subprocess.TimeoutExpired: os.killpg(p.pid,signal.SIGKILL); p.wait(timeout=15)
            time.sleep(5); snapshot(out,'after-cleanup.txt'); result.update(finished=time.time(),server_returncode=p.returncode); save(out/'result.json',result); print('DONE',name,result['ok'],flush=True)
    return result['ok']
if __name__=='__main__': main(sys.argv[1],sys.argv[2]=='on',int(sys.argv[3]),int(sys.argv[4]) if len(sys.argv)>4 else 4096,int(sys.argv[5]) if len(sys.argv)>5 else 4)
