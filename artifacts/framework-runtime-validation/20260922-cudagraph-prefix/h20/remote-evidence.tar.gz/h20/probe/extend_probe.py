from pathlib import Path
p=Path(__file__).with_name('sitecustomize.py')
s=p.read_text().replace('def capture(obj, event):','def capture(obj, event, return_value=None):').replace('record = {"event": event,','record = {"return_value": describe(return_value), "event": event,')
s=s.replace('"max_total_num_tokens", "num_mamba_layers"):', '"max_total_num_tokens", "num_mamba_layers", "block_size", "hash_block_size", "scheduler_block_size", "available_kv_cache_memory_bytes", "cudagraph_memory_estimate", "requested_memory", "total_consumed", "peak_activation_memory", "num_gpu_blocks", "mamba_cache_mode"):')
s=s.replace('    out = Path(os.environ["MSV_RUNTIME_OUT"])\n    out.mkdir', '    cfg = getattr(obj, "vllm_config", None)\n    if cfg is not None:\n        record["compilation_config"] = str(cfg.compilation_config)\n        record["cache_config"] = str(cfg.cache_config)\n    out = Path(os.environ["MSV_RUNTIME_OUT"])\n    out.mkdir',1)
s=s.replace('capture(self, f"{cls.__name__}.{method}")','capture(self, f"{cls.__name__}.{method}", result)')
s=s.replace('["load_model", "initialize_kv_cache"]','["load_model", "initialize_kv_cache", "profile_cudagraph_memory", "capture_model"]')
s=s.replace('TARGETS = {','TARGETS = {\n    "vllm.v1.worker.gpu_worker": {"Worker": ["determine_available_memory", "compile_or_warm_up_model"]},\n    "vllm.v1.core.kv_cache_manager": {"KVCacheManager": ["__init__"]},')
p.write_text(s)
